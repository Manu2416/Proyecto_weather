import mysql.connector
import json   
import requests
from datetime import datetime

def crear_conexion():
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="1234",
            database="temperaturas"
        )
        return conexion
    
    except mysql.connector.Error as err:
        print("No se puede hacer conexión:", err)
        return None

def isnertar_paises(conexion,lista_paises):
    cursor = conexion.cursor()
    consulta = "INSERT INTO paises (cca2,cca3,nombre,capital,region,subregion,miembroUE,latitud,longitud) VALUES ( %s,%s,%s,%s,%s,%s,%s,%s,%s)"

    for pais in lista_paises:

            nombre = pais.get("name", {}).get("common")
            capital = pais["capital"][0]
            latlng = pais.get("latlng", [None, None])#esto me lo dio chat porque si no me daba index error porque habia algunas vacias
            latitud = latlng[0]
            longitud = latlng[1]

            valores = (
                pais.get("cca2"),
                pais.get("cca3"),
                nombre,
                capital,
                pais.get("region"),
                pais.get("subregion"),
                pais.get("unMember"),
                latitud,
                longitud
            )

            cursor.execute(consulta, valores)

    # Confirmar los cambios
    conexion.commit()

def insertar_fronteras(conexion,lista_paises):
    cursor = conexion.cursor()
    for pais in lista_paises:
        # Lo buscamos por su cca3 
        cursor.execute("SELECT idpais FROM paises WHERE cca3 = %s", (pais.get('cca3'),))
        resultado = cursor.fetchone()
        
        if resultado:
            id_pais_principal = resultado[0]
            lista_fronteras = pais.get("borders", []) # Esto es una lista

            #Como e reccoremos la lisra de fronteras y la vamos metiendo 
            for frontera_cca3 in lista_fronteras:
                consulta_frontera = "INSERT INTO fronteras (idpais, cca3_frontera) VALUES (%s, %s)"
                cursor.execute(consulta_frontera, (id_pais_principal, frontera_cca3))

    # Confirmar cambios finales
    conexion.commit()

    # Cerrar todo
    cursor.close()
    conexion.close()
    

def leer_json():
    with open("paises_europa.json", "r", encoding="utf-8") as archivo:
         paises = json.load(archivo)
         return paises
    
def visualizar_temperatura(conexion,pais):
    cursor = conexion.cursor()
    #seleccionamos el id del pais que nos pasan
    cursor.execute("Select idpais FROM paises WHERE cca3 = %s",[pais])
    resultado = cursor.fetchone()
    id_pais = resultado[0]
    #con el id seleccionamos la temperatura
    cursor.execute("Select temperatura FROM temperaturas WHERE idpais = %s ORDER BY timestamp DESC LIMIT 1",[id_pais] )
    temperatura = cursor.fetchone()
    conexion.commit()
    cursor.close()
    return temperatura

def ver_fronteras(conexion,pais):
    #selecciono el id del pais
    cursor = conexion.cursor()
    cursor.execute("SELECT idpais FROM paises where cca3 = %s",[pais])
    resultado = cursor.fetchone()
    id_pais = resultado[0]
    #busco sus fronteras
    cursor.execute("Select cca3_frontera from fronteras where idpais = %s",[id_pais])
    fronteras = cursor.fetchall()

    return fronteras
def ver_paises(conexion):
    cursor = conexion.cursor()
    cursor.execute("SELECT cca3 FROM paises")
    resultado = cursor.fetchone()

    return resultado
   






def insertar_temps(conexion, paises):
    api_key = "0bfe1323d65ba70d1453570dbad38e3c"
    cursor = conexion.cursor()
    #selecionamos el pais con la latitud y longitud
    for pais in paises:
        cursor.execute("SELECT idpais, latitud, longitud FROM paises WHERE cca3 = %s", (pais.get('cca3'),))
        resultado = cursor.fetchone()
        
        #usamos la api para relacionar sus datos 
        id_pais, latitud, longitud = resultado
        datos_clima = obtener_clima(latitud, longitud, api_key)
        
        if datos_clima and "main" in datos_clima:
            main = datos_clima["main"]
            sys = datos_clima.get("sys", {})
            #Esto me lo hizo chat porque el la bdd si no lo pones en formato bueno no te deja
            fecha_medicion = datetime.fromtimestamp(datos_clima.get("dt")).strftime('%Y-%m-%d %H:%M:%S')
            amanecer = datetime.fromtimestamp(sys.get("sunrise")).strftime('%Y-%m-%d %H:%M:%S')
            atardecer = datetime.fromtimestamp(sys.get("sunset")).strftime('%Y-%m-%d %H:%M:%S')
            
            
            valores = (
                id_pais,
                fecha_medicion,
                main.get("temp"), 
                main.get("feels_like"), 
                main.get("temp_min"), 
                main.get("temp_max"), 
                main.get("humidity"),                
                amanecer,                 
                atardecer    
            )
            
            consulta = "INSERT INTO temperaturas(idpais,timestamp, temperatura, sensacion, minima, maxima, humedad, amanecer, atardecer) VALUES (%s,%s, %s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(consulta, valores)

    conexion.commit()
    cursor.close()

def obtener_clima(lat, lon, api_key):
    url = "https://api.openweathermap.org/data/2.5/weather"
    #https://api.openweathermap.org/data/3.0/onecall?lat={lat}&lon={lon}&exclude={part}&appid={API key}
    parametros = {"lat": lat, "lon": lon, "appid": api_key}
    respuesta = requests.get(url, params=parametros)
    
    if respuesta.status_code == 200:
        return respuesta.json()
    else:
        return None